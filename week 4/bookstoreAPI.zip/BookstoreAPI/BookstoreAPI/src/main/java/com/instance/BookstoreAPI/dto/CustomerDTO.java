// CustomerDTO.java
package com.example.BookstoreAPI.dto;

public class CustomerDTO {
    private Long id;
    private String name;
    private String email;

    // Getters and setters
}

